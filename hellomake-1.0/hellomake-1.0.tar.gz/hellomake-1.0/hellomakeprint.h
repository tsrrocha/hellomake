#ifndef _HELLOMAKEPRINT_H_
#define _HELLOMAKEPRINT_H_

// Protótipo da função
void printHello( void );

#endif // _HELLOMAKEPRINT_H_
