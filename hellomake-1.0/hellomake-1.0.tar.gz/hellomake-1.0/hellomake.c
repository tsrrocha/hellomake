/*==================================================
                    HELLO
  --------------------------------------------------


  ==================================================*/
  
  #include <stdio.h>
  #include <stdlib.h>
  #include "hellomakeprint.h"
  #include "hellomake.h"

  int main () {
      printHello();
      return (0);
  }
