#include <stdio.h>
#include "hellomakeprint.h"

void printHello( void ) {
    fprintf(stdout, "\n");
    fprintf(stdout, "HelloMake - DEBUG - Ola, mundo legal!!!\n");
    fprintf(stdout, "\n");
}
